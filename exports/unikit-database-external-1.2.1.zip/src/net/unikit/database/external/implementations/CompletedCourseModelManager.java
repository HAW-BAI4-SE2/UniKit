package net.unikit.database.external.implementations;

import net.unikit.database.external.interfaces.entities.DidacticUnitModel;
import net.unikit.database.external.interfaces.managers.AbstractModelManager;

/**
 * Created by Andreas on 19.11.2015.
 */
interface CompletedCourseModelManager extends AbstractModelManager<CompletedCourseModel, Integer> {
}
