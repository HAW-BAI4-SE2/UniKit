package net.unikit.database.external.interfaces.managers;

import net.unikit.database.external.interfaces.entities.CourseModel;

/**
 * Created by Andreas on 19.11.2015.
 */
public interface CourseModelManager extends AbstractModelManager<CourseModel, Integer> {
}
