package net.unikit.database.external.interfaces.managers;

import net.unikit.database.external.interfaces.entities.FieldOfStudyModel;

/**
 * Created by Andreas on 19.11.2015.
 */
public interface FieldOfStudyModelManager extends AbstractModelManager<FieldOfStudyModel, Integer> {
}
