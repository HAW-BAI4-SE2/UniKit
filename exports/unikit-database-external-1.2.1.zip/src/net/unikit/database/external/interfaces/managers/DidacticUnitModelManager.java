package net.unikit.database.external.interfaces.managers;

import net.unikit.database.external.interfaces.entities.DidacticUnitModel;

/**
 * Created by Andreas on 19.11.2015.
 */
public interface DidacticUnitModelManager extends AbstractModelManager<DidacticUnitModel, Integer> {
}
