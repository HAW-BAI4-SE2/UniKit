package net.unikit.database.external.interfaces.managers;

import net.unikit.database.external.interfaces.entities.AppointmentModel;

/**
 * Created by Andreas on 19.11.2015.
 */
public interface AppointmentModelManager extends AbstractModelManager<AppointmentModel, Integer> {
}
