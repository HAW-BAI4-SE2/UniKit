package net.unikit.database.external.interfaces.entities;

/**
 * Created by Andreas on 19.11.2015.
 */
public interface AbstractModel<IdType> {
    IdType getId();
}
