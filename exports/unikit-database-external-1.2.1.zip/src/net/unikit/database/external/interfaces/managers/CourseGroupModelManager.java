package net.unikit.database.external.interfaces.managers;

import net.unikit.database.external.interfaces.entities.CourseGroupModel;

/**
 * Created by Andreas on 19.11.2015.
 */
public interface CourseGroupModelManager extends AbstractModelManager<CourseGroupModel, Integer> {
}
