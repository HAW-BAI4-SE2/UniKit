package net.unikit.database.external.interfaces.managers;

import net.unikit.database.external.interfaces.entities.CourseLectureModel;

/**
 * Created by Andreas on 19.11.2015.
 */
public interface CourseLectureModelManager extends AbstractModelManager<CourseLectureModel, Integer> {
}
