package net.unikit.database.external.interfaces.managers;

import net.unikit.database.external.interfaces.entities.CourseLectureAppointmentModel;

/**
 * Created by Andreas on 19.11.2015.
 */
public interface CourseLectureAppointmentModelManager extends AbstractModelManager<CourseLectureAppointmentModel, Integer> {
}
