package net.unikit.database.internal.interfaces.managers;

import net.unikit.database.internal.interfaces.entities.TeamInvitationModel;

/**
 * Created by Andreas on 19.11.2015.
 */
public interface TeamInvitationModelManager extends AbstractModelManager<TeamInvitationModel, Integer> {
}
