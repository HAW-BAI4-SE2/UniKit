package net.unikit.database.internal.interfaces.managers;

import net.unikit.database.internal.interfaces.entities.MembershipRequestModel;

/**
 * Created by Andreas on 19.11.2015.
 */
public interface MembershipRequestModelManager extends AbstractModelManager<MembershipRequestModel, Integer> {
}
