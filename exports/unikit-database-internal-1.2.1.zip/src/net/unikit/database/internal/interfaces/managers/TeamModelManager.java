package net.unikit.database.internal.interfaces.managers;

import net.unikit.database.internal.interfaces.entities.TeamModel;

/**
 * Created by Andreas on 19.11.2015.
 */
public interface TeamModelManager extends AbstractModelManager<TeamModel, Integer> {
}
