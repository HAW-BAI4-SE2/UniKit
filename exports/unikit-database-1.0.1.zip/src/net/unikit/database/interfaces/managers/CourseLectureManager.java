package net.unikit.database.interfaces.managers;

import net.unikit.database.interfaces.entities.CourseLecture;

public interface CourseLectureManager extends AbstractManager<CourseLecture, CourseLecture.ID> {
}
