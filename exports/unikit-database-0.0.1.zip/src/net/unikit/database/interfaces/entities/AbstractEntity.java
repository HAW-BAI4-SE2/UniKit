package net.unikit.database.interfaces.entities;

public interface AbstractEntity {
}
