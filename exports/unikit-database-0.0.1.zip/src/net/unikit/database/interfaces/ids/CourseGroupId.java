package net.unikit.database.interfaces.ids;

public interface CourseGroupId extends DidacticUnitId, AbstractId<Integer> {
}
