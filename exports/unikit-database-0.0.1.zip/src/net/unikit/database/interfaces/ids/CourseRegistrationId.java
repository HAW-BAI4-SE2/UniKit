package net.unikit.database.interfaces.ids;

public interface CourseRegistrationId extends AbstractId<Integer> {
}
