package net.unikit.database.interfaces.ids;

public interface CourseLectureId extends AbstractId<Integer> {
}
