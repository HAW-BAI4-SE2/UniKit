package net.unikit.database.interfaces.ids;

public interface FieldOfStudyId extends AbstractId<Integer> {
}
