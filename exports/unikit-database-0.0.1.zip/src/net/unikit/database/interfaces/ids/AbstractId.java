package net.unikit.database.interfaces.ids;

public interface AbstractId<T> {
    T getValue();
}
