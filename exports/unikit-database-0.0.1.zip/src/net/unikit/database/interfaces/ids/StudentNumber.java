package net.unikit.database.interfaces.ids;

public interface StudentNumber extends AbstractId<String> {
}
