package net.unikit.database.interfaces.ids;

public interface DidacticUnitId extends AbstractId<Integer>  {
}
