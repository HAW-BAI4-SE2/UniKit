package net.unikit.database.interfaces.ids;

public interface AppointmentId extends AbstractId<Integer> {
}
