package net.unikit.database.interfaces.ids;

public interface CourseLectureAppointmentId extends AbstractId<Integer> {
}
