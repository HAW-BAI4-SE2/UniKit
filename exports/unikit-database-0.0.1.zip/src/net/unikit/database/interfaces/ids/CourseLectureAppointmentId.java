package net.unikit.database.interfaces.ids;

public interface CourseLectureAppointmentId extends AppointmentId, AbstractId<Integer> {
}
