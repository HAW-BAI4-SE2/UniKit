package net.unikit.database.interfaces.ids;

public interface CourseGroupAppointmentId extends AbstractId<Integer> {
}
