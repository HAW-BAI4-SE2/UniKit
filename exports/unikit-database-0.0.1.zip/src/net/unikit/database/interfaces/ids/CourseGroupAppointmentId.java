package net.unikit.database.interfaces.ids;

public interface CourseGroupAppointmentId extends AppointmentId, AbstractId<Integer> {
}
