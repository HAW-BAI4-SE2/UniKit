package net.unikit.database.interfaces.ids;

public interface TeamInvitationId extends AbstractId<Integer> {
}
