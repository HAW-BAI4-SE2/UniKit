package net.unikit.database.interfaces.managers;

import net.unikit.database.interfaces.entities.DidacticUnit;
import net.unikit.database.interfaces.ids.DidacticUnitId;

public interface DidacticUnitManager extends AbstractManager<DidacticUnit, DidacticUnitId> {
}
