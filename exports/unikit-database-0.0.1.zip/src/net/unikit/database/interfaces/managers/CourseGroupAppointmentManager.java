package net.unikit.database.interfaces.managers;

import net.unikit.database.interfaces.entities.CourseGroupAppointment;
import net.unikit.database.interfaces.ids.CourseGroupAppointmentId;

public interface CourseGroupAppointmentManager extends AbstractManager<CourseGroupAppointment, CourseGroupAppointmentId> {
}
