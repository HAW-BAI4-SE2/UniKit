package net.unikit.database.interfaces.managers;

import net.unikit.database.interfaces.entities.CourseRegistration;
import net.unikit.database.interfaces.ids.CourseRegistrationId;

public interface CourseRegistrationManager extends AbstractManager<CourseRegistration, CourseRegistrationId> {
}
