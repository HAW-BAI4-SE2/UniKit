package net.unikit.database.interfaces.managers;

import net.unikit.database.interfaces.entities.CourseGroup;
import net.unikit.database.interfaces.ids.CourseGroupId;

public interface CourseGroupManager extends AbstractManager<CourseGroup, CourseGroupId> {
}
