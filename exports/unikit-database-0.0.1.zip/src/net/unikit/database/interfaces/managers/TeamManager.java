package net.unikit.database.interfaces.managers;

import net.unikit.database.interfaces.entities.Team;
import net.unikit.database.interfaces.ids.TeamId;

public interface TeamManager extends AbstractManager<Team, TeamId> {
}
