package net.unikit.database.interfaces.managers;

import net.unikit.database.interfaces.entities.Course;
import net.unikit.database.interfaces.ids.CourseId;

public interface CourseManager extends AbstractManager<Course, CourseId> {
}
