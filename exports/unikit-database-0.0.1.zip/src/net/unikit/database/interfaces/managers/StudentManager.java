package net.unikit.database.interfaces.managers;

import net.unikit.database.interfaces.entities.Student;
import net.unikit.database.interfaces.ids.StudentNumber;

public interface StudentManager extends AbstractManager<Student, StudentNumber> {
}
