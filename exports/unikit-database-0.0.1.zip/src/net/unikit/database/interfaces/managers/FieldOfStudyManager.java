package net.unikit.database.interfaces.managers;

import net.unikit.database.interfaces.entities.FieldOfStudy;
import net.unikit.database.interfaces.ids.FieldOfStudyId;

public interface FieldOfStudyManager extends AbstractManager<FieldOfStudy, FieldOfStudyId> {
}
